import { ModuleWithProviders } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Routes, RouterModule } from '@angular/router';

import { HeaderComponent } from '../design/header/component/header.component';
import { FooterComponent } from '../design/footer/component/footer.component';
import { BaseComponent } from '../design/base/component/base.component';
import { LandingPageComponent } from '../design/landing-page/component/landing-page.component';
import { LeftPanelComponent } from '../design/left-panel/component/left-panel.component';

// Before Login modules







const routes: Routes = [


  {
    path: '',
    component: BaseComponent,

    children: [
      {
        path: '',
        component: LandingPageComponent,

      },

      {
        path: 'home',
        component: LandingPageComponent,

      },

    



    ]
  },

]

export const AppRouting: ModuleWithProviders = RouterModule.forRoot(routes, { enableTracing: false, useHash: true });

