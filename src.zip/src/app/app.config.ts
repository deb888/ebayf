export const AppUrlsConst: any = {
    /** Live URL ALL */
    API_URL: 'http://192.168.0.102:5000',
    


}
