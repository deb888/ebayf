import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { AppRouting } from './router/app.router';
import { HeaderModule } from './design/header/header.module';
import { FooterModule } from './design/footer/footer.module';
import { BaseModule } from './design/base/base.module';
import { LandingPageModule } from './design/landing-page/landing-page.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { LeftPanelModule } from './design/left-panel/left-panel.module';
import { HttpService } from './globalservice';
import { RequestInterceptorService } from './interceptor';


@NgModule({
  declarations: [
    AppComponent,

  ],

  imports: [
    BrowserModule,
    AppRouting,
    HeaderModule,
    FooterModule,
    BaseModule,
    LandingPageModule,
    LeftPanelModule,
    HttpClientModule,
    BrowserAnimationsModule,
    BsDropdownModule.forRoot()
    
  ],
  providers: [{ provide: HTTP_INTERCEPTORS, useClass: RequestInterceptorService, multi: true },HttpService],
  bootstrap: [AppComponent]
})
export class AppModule { }
